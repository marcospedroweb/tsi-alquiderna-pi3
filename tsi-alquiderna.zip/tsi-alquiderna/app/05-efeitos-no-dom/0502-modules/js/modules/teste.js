export function teste1() {
  console.log('Isso é teste')
}

export function teste2() {
  console.log('Isso é teste skjdljks')
}

const esseNome = 'Andre';

export const senha = 2928219082190;