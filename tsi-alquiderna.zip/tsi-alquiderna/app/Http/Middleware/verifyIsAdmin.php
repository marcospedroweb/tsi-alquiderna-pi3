<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class verifyIsAdmin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
<<<<<<< HEAD
<<<<<<< HEAD
        if (!auth()->user()->VerifyIsAdmin())
            return redirect(route('index'));
=======
>>>>>>> ff9914ec0f7efd169e2e52e44b749b687394fc87
=======
>>>>>>> ff9914ec0f7efd169e2e52e44b749b687394fc87
        return $next($request);
    }
}
