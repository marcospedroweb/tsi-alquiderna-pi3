
<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-5 bg-white sticky-top">
        <h2>Produto</h2>
        <div>
            <a href="<?php echo e(route('product.index')); ?>" class="btn btn-primary active">Listar produtos</a>
            <a href="<?php echo e(route('product.create')); ?>" class="btn btn-primary">Criar produto</a>
            <a href="<?php echo e(route('product.trash')); ?>" class="btn btn-primary">Lixeira produto</a>
            <a href="<?php echo e(route('crud.index')); ?>" class="btn btn-secondary">Crud geral</a>
        </div>
    </div>
    <div class="my-5">
        <span>Quantidade de produtos: <?php echo e(count($products)); ?></span>
    </div>
    <div class="row justify-content-between align-items-center mb-6">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col col-lg-4 row bg-secondary p-3 flex-column justify-content-center align-items-center mb-4">
                <div class="col justify-content-center align-items-center">
                    <div class="card-product-view position-relative overflow-hidden mx-auto mb-3">
                        <img src='<?php echo e(asset("$product->image")); ?>' class="img-fluid">
                        <div
                            class="card-product-view-text w-100 position-absolute bottom-0 start-50 translate-middle-x d-flex flex-column">
                            <div class="d-flex flex-column">
                                <h3 class="d-flex flex-column justify-content-start align-items-start"
                                    style="word-wrap: break-word;">
                                    <?php if($product->new === 1): ?>
                                        <span class="novidade me-2">novo</span>
                                        <span class="ms-2"><?php echo e($product->name); ?></span>
                                    <?php else: ?>
                                        <?php echo e($product->name); ?>

                                    <?php endif; ?>

                                </h3>
                                <p><?php echo e($product->Category->name); ?> <?php echo e($product->ItemClass->name); ?>, nível
                                    <?php echo e($product->lvlMin); ?>

                                </p>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="attributes d-flex justify-content-between align-items-center">
                                    <?php if($product->Category->name === 'Armadura'): ?>
                                        <div class="attribute d-flex justify-content-center align-items-center">
                                            <i class="bi bi-heart-fill"></i>
                                            <span><?php echo e($product->life); ?></span>
                                        </div>
                                        <div class="attribute d-flex justify-content-center align-items-center">
                                            <i class="fa-solid fa-person-running"></i>
                                            <span><?php echo e($product->speed); ?></span>
                                        </div>
                                        <div class="attribute d-flex justify-content-center align-items-center">
                                            <i class="bi bi-shield-slash-fill"></i>
                                            <span><?php echo e($product->physical_protection); ?></span>
                                        </div>
                                        <div class="attribute d-flex justify-content-center align-items-center">
                                            <svg class="shield-moon" width="16" height="20" viewBox="0 0 16 20"
                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M8 0L0 3V9.09C0 14.14 3.41 18.85 8 20C12.59 18.85 16 14.14 16 9.09V3L8 0ZM14 9.09C14 13.09 11.45 16.79 8 17.92C4.55 16.79 2 13.1 2 9.09V4.39L8 2.14L14 4.39V9.09Z"
                                                    fill="#771CA3" />
                                                <path
                                                    d="M5.01007 12.33C6.76007 14.5 10.1301 14.57 11.9701 12.4C12.2001 12.13 12.0501 11.72 11.7101 11.66C10.4201 11.45 9.23007 10.68 8.53007 9.46003C7.82007 8.24003 7.75007 6.83003 8.21007 5.60003C8.33007 5.27003 8.05006 4.94003 7.70006 5.00003C4.36006 5.62003 2.81007 9.61003 5.01007 12.33Z"
                                                    fill="#771CA3" />
                                            </svg>
                                            <span><?php echo e($product->magic_protection); ?></span>
                                        </div>
                                    <?php elseif($product->Category->name === 'Poção' && $product->ItemClass->name === 'Vida'): ?>
                                        <div class="attribute d-flex justify-content-center align-items-center">
                                            <i class="bi bi-heart-fill"></i>
                                            <span><?php echo e($product->life); ?></span>
                                        </div>
                                    <?php elseif($product->Category->name === 'Poção' && $product->ItemClass->name === 'Força'): ?>
                                        <div class="attribute d-flex justify-content-center align-items-center">
                                            <i class="bi bi-shield-slash-fill"></i>
                                            <span><?php echo e($product->physical_attack); ?></span>
                                        </div>
                                    <?php elseif($product->Category->name === 'Poção' && $product->ItemClass->name === 'Mana'): ?>
                                        <div class="attribute d-flex justify-content-center align-items-center">
                                            <i class="fa-solid fa-droplet"></i>
                                            <span><?php echo e($product->mana); ?></span>
                                        </div>
                                    <?php else: ?>
                                        <div class="attribute d-flex justify-content-center align-items-center">
                                            <i class="fa-solid fa-user-slash"></i>
                                            <span><?php echo e($product->physical_attack); ?></span>
                                        </div>
                                        <div class="attribute d-flex justify-content-center align-items-center">
                                            <i class="fa-solid fa-wand-sparkles"></i>
                                            <span><?php echo e($product->magic_attack); ?></span>
                                        </div>
                                        <div class="attribute d-flex justify-content-center align-items-center">
                                            <i class="fa-solid fa-droplet"></i>
                                            <span><?php echo e($product->mana); ?></span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="card-product-view-price">
                                    <div class="d-flex flex-column align-items-end">
                                        <?php if($product->discount_price !== 0.0): ?>
                                            <p class="text-decoration-line-through">R$ <span
                                                    class="product-price"><?php echo e($product->price); ?></span></p>
                                            <p class="p-product-price">R$ <span
                                                    class="product-discount-price"><?php echo e($product->discount_price); ?></span>
                                            </p>
                                        <?php else: ?>
                                            <p class="p-product-price">R$ <span
                                                    class="product-price"><?php echo e($product->price); ?></span></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="div-product-info col justify-content-center align-items-center">
                    <h3 class="h3 mb-3 fw-bold text-center">Photo tirada por <a
                            href="<?php echo e($product->author_link); ?>"><?php echo e($product->author_name); ?></a> em <a
                            href="<?php echo e($product->source_website_link); ?>"><?php echo e($product->SourceWebsite->name); ?></a>
                    </h3>
                    <p class="recommendation-text"><?php echo e($product->recommendation); ?></p>
                    <div>
                        <div class="d-flex mb-3">
                            <div class="product-info d-flex flex-column justify-content-center align-items-center">
                                <div>
                                    <span class="fw-bold">Nível minimo</span>
                                </div>
                                <span><?php echo e($product->lvlMin); ?></span>
                            </div>
                            <div class="product-info d-flex flex-column justify-content-center align-items-center">
                                <div>
                                    <span class="fw-bold">Nível maximo</span>
                                </div>
                                <span><?php echo e($product->lvlMax); ?></span>
                            </div>
                        </div>
                        <div class="d-flex mb-3">
                            <div class="product-info d-flex flex-column justify-content-center align-items-center">
                                <div>
                                    <span class="fw-bold">Encantamento</span>
                                </div>
                                <?php if($product->enchant === 0): ?>
                                    <span>Não</span>
                                <?php else: ?>
                                    <span>Sim</span>
                                <?php endif; ?>
                            </div>
                            <div class="product-info d-flex flex-column justify-content-center align-items-center">
                                <div>
                                    <span class="fw-bold">Promoção</span>
                                </div>
                                <?php if($product->sale === 0): ?>
                                    <span>Não</span>
                                <?php else: ?>
                                    <span>Sim</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center align-items-center mb-3">
                            <a href="<?php echo e(route('product.edit', $product->id)); ?>"
                                class="btn btn-lg btn-primary me-4">Editar</a>
                            <a href="<?php echo e(route('product.destroy', $product->id)); ?>"
                                class="btn btn-lg btn-danger">Apagar</a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tsi-alquiderna\resources\views/product/index.blade.php ENDPATH**/ ?>