
<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-5">
        <h2>Crud geral</h2>
        <div>
            <a href="<?php echo e(route('product.index')); ?>" class="btn btn-primary">Produtos</a>
            <a href="<?php echo e(route('category.index')); ?>" class="btn btn-primary">Categorias</a>
            <a href="<?php echo e(route('itemClass.index')); ?>" class="btn btn-primary">Classes</a>
            <a href="<?php echo e(route('sourceWebsite.index')); ?>" class="btn btn-primary">Site fontes</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tsi-alquiderna\resources\views/crud.blade.php ENDPATH**/ ?>